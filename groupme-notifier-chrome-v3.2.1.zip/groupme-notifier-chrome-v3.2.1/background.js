// GroupMe Notifier - Background Script (Chrome MV3)
// Dev: Yousab
// v3.2.0 — Keepalive port trick to prevent service worker from sleeping,
//           which caused "Extension context invalidated" errors in content.js.

const GROUPME_API = "https://api.groupme.com/v3";
const MAX_HISTORY = 20;

// ── Keepalive — prevent MV3 service worker from sleeping ─────────────────────
// Chrome suspends service workers after ~30s of inactivity.
// Opening a persistent port to ourselves keeps the worker alive.

function keepAlive() {
  // Connect a port to ourselves; Chrome won't suspend a worker with an open port
  const port = chrome.runtime.connect({ name: "keepalive" });
  port.onDisconnect.addListener(() => {
    // Port died (Chrome closed it after ~5 min) — reconnect immediately
    if (chrome.runtime?.id) {
      keepAlive();
    }
  });
}

// ── Startup & Alarms ─────────────────────────────────────────────────────────
// Alarms (min 1 min) act as a guaranteed heartbeat in case the keepalive
// port ever lapses (e.g. device sleep). Content script pings cover sub-minute.

chrome.runtime.onInstalled.addListener(() => {
  keepAlive();
  chrome.alarms.create("gm-poll", { periodInMinutes: 1 });
  poll();
});

chrome.runtime.onStartup.addListener(() => {
  keepAlive();
  chrome.alarms.create("gm-poll", { periodInMinutes: 1 });
  poll();
});

// Re-establish keepalive every time the worker wakes from an alarm
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "gm-poll") {
    keepAlive();
    poll();
  }
});

// ── Message handler ──────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.action === "poll") {
    poll().then(() => sendResponse({ ok: true })).catch(() => sendResponse({ ok: false }));
    return true;
  }
  if (msg.action === "verifyToken") {
    fetch(`${GROUPME_API}/users/me?token=${msg.token}`)
      .then(r => r.json())
      .then(data => sendResponse({ ok: true, user: data.response }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }
  if (msg.action === "loadGroups") {
    getStorage(["token"]).then(({ token }) => {
      if (!token) { sendResponse({ ok: false }); return; }
      fetch(`${GROUPME_API}/groups?per_page=100&token=${token}`)
        .then(r => r.json())
        .then(data => sendResponse({ ok: true, groups: data.response }))
        .catch(() => sendResponse({ ok: false }));
    });
    return true;
  }
  if (msg.action === "clearToken") {
    chrome.storage.local.remove(
      ["token", "lastMessageIds", "userName", "userPhone", "userAvatar", "notifCount", "notifHistory"],
      () => sendResponse({ ok: true })
    );
    return true;
  }
});

// Handle the keepalive port on the receiving end (connect to self)
chrome.runtime.onConnect.addListener((port) => {
  if (port.name === "keepalive") {
    // Just holding the port open is enough — no messages needed
    port.onDisconnect.addListener(() => {});
  }
});

chrome.notifications.onClicked.addListener(() => {
  chrome.action.setBadgeText({ text: "" });
});

// ── Rate limit protection ────────────────────────────────────────────────────

let isPolling = false;

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

// ── Core polling ─────────────────────────────────────────────────────────────

async function poll() {
  if (isPolling) return;
  isPolling = true;
  try {
    await doPoll();
  } catch (err) {
    console.error("[GroupMe Notifier] Poll error:", err);
  } finally {
    isPolling = false;
  }
}

async function doPoll() {
  const { token } = await getStorage(["token"]);
  if (!token) return;

  const { lastMessageIds = {} } = await getStorage(["lastMessageIds"]);
  const newLastIds  = { ...lastMessageIds };
  const newMessages = [];

  const groupsRes = await apiFetch(`/groups?per_page=100&token=${token}`);
  if (!groupsRes?.response) return;

  for (const group of groupsRes.response) {
    await checkConversation({
      id: `group_${group.id}`,
      name: group.name,
      messagesInfo: group.messages,
      token,
      lastMessageIds,
      newLastIds,
      newMessages,
      msgEndpoint: `/groups/${group.id}/messages`,
    });

    await sleep(150); // reduced from 300ms — cuts total poll time in half

    try {
      const subRes = await apiFetch(`/groups/${group.id}/subgroups?per_page=100&token=${token}`);
      const subgroups = subRes?.response;
      if (Array.isArray(subgroups)) {
        for (const sub of subgroups) {
          await checkConversation({
            id: `sub_${sub.id}`,
            name: `${group.name} › ${sub.topic}`,
            messagesInfo: sub.messages,
            token,
            lastMessageIds,
            newLastIds,
            newMessages,
            msgEndpoint: `/groups/${sub.id}/messages`,
          });
          await sleep(150);
        }
      }
    } catch (e) {
      if (e.message.includes("429")) {
        console.warn("[GroupMe Notifier] Rate limited — backing off 10s");
        await sleep(10000);
      }
    }
  }

  await setStorage({ lastMessageIds: newLastIds });

  if (newMessages.length > 0) {
    const byGroup = {};
    for (const m of newMessages) {
      if (!byGroup[m.groupName]) byGroup[m.groupName] = [];
      byGroup[m.groupName].push(m);
    }
    for (const [groupName, msgs] of Object.entries(byGroup)) {
      if (msgs.length === 1) fireNotification(msgs[0]);
      else fireBatchNotification(groupName, msgs);
    }

    const badgeText = newMessages.length > 99 ? "99+" : String(newMessages.length);
    chrome.action.setBadgeText({ text: badgeText });
    chrome.action.setBadgeBackgroundColor({ color: "#E8462A" });

    const { notifCount = 0 } = await getStorage(["notifCount"]);
    await setStorage({ notifCount: notifCount + newMessages.length });

    const { notifHistory = [] } = await getStorage(["notifHistory"]);
    const newEntries = newMessages.map(m => ({
      sender:    m.sender,
      groupName: m.groupName,
      text:      m.text,
      ts:        Date.now(),
    }));
    const updatedHistory = [...newEntries, ...notifHistory].slice(0, MAX_HISTORY);
    await setStorage({ notifHistory: updatedHistory });
  }
}

async function checkConversation({ id, name, messagesInfo, token, lastMessageIds, newLastIds, newMessages, msgEndpoint }) {
  const lastMsg = messagesInfo?.last_message_id;
  const preview = messagesInfo?.preview;

  if (!lastMsg) return;

  const knownId = lastMessageIds[id];

  if (!knownId) {
    newLastIds[id] = lastMsg;
    return;
  }

  if (lastMsg !== knownId) {
    try {
      const msgs = await apiFetch(`${msgEndpoint}?limit=20&token=${token}`);
      if (msgs?.response?.messages) {
        const fresh = msgs.response.messages.filter(m => m.id > knownId);
        for (const m of fresh) {
          newMessages.push({
            groupName: name,
            sender: m.name,
            text: m.text || (m.attachments?.length ? "📎 Attachment" : "(no text)"),
            msgId: m.id,
          });
        }
      }
    } catch {
      if (preview) {
        newMessages.push({
          groupName: name,
          sender: preview.nickname || "Someone",
          text: preview.text || "(message)",
          msgId: lastMsg,
        });
      }
    }
    newLastIds[id] = lastMsg;
  }
}

function fireNotification({ groupName, sender, text, msgId }) {
  chrome.notifications.create(`gm-${msgId}`, {
    type: "basic",
    iconUrl: "icons/icon128.png",
    title: `${sender} in ${groupName}`,
    message: text,
    priority: 2,
  });
}

function fireBatchNotification(groupName, msgs) {
  chrome.notifications.create(`gm-batch-${Date.now()}`, {
    type: "basic",
    iconUrl: "icons/icon128.png",
    title: `${msgs.length} new messages in ${groupName}`,
    message: msgs.map(m => `${m.sender}: ${m.text}`).slice(0, 4).join("\n"),
    priority: 2,
  });
}

// ── Helpers ──────────────────────────────────────────────────────────────────

async function apiFetch(path) {
  const res = await fetch(`${GROUPME_API}${path}`);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

function getStorage(keys) {
  return new Promise(r => chrome.storage.local.get(keys, r));
}

function setStorage(data) {
  return new Promise(r => chrome.storage.local.set(data, r));
}
