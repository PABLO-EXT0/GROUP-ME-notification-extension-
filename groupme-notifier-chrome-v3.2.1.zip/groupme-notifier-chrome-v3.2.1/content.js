// GroupMe Notifier — Content Script (Chrome)
// Dev: Yousab
// v3.2.1 — Eliminated "Could not establish connection. Receiving end does not exist."
// Chrome logs this as an *unchecked* runtime error when the service worker hasn't
// fully started yet. The fix: use the callback form of sendMessage instead of the
// Promise form — Chrome silences the error when lastError is read inside the callback.

const POLL_INTERVAL_SECONDS = 15;

function isExtensionAlive() {
  try {
    return !!chrome.runtime?.id;
  } catch {
    return false;
  }
}

// Sends a message using the callback form so Chrome considers lastError "checked",
// which suppresses the unchecked runtime error in the Extensions panel.
function safeSendPoll(onFail) {
  chrome.runtime.sendMessage({ action: "poll" }, (_response) => {
    // Reading lastError here is what silences the console/Extensions-panel error.
    const err = chrome.runtime.lastError;
    if (err) {
      onFail && onFail(err);
    }
  });
}

function triggerPoll() {
  if (!isExtensionAlive()) {
    clearInterval(pollInterval);
    return;
  }

  safeSendPoll((err) => {
    // Worker was asleep — retry once after 1s to let Chrome spin it back up
    if (!isExtensionAlive()) {
      clearInterval(pollInterval);
      return;
    }
    setTimeout(() => {
      if (!isExtensionAlive()) return;
      safeSendPoll(); // silent retry — if it fails again, just wait for next interval
    }, 1000);
  });
}

triggerPoll();
const pollInterval = setInterval(triggerPoll, POLL_INTERVAL_SECONDS * 1000);

console.log("[GroupMe Notifier] Content script loaded, polling every " + POLL_INTERVAL_SECONDS + "s");
