// GroupMe Notifier — Popup Script (Chrome MV3)
// Dev: Yousab — Enhanced UI

const GROUPME_API = "https://api.groupme.com/v3";
const MAX_HISTORY = 20;

const viewLogin  = document.getElementById("view-login");
const viewMain   = document.getElementById("view-main");
const dot        = document.getElementById("status-dot");
const statusText = document.getElementById("status-text");
const pollStatus = document.getElementById("poll-status");

function getStorage(keys) {
  return new Promise(r => chrome.storage.local.get(keys, r));
}
function setStorage(data) {
  return new Promise(r => chrome.storage.local.set(data, r));
}
function sendMsg(msg) {
  return new Promise(r => chrome.runtime.sendMessage(msg, r));
}

async function init() {
  chrome.action.setBadgeText({ text: "" });
  const { token, notifCount } = await getStorage(["token", "notifCount"]);
  if (!token) showLogin();
  else await showMain(token, notifCount || 0);
}

// ── Login ────────────────────────────────────────────────────────────────────

function showLogin() {
  viewLogin.classList.add("active");
  viewMain.classList.remove("active");
  dot.className = "status-dot error";
  statusText.textContent = "OFF";
  pollStatus.textContent = "NOT CONNECTED";

  document.getElementById("save-btn").addEventListener("click", saveToken);
  document.getElementById("token-input").addEventListener("keydown", e => {
    if (e.key === "Enter") saveToken();
  });
}

async function saveToken() {
  const token = document.getElementById("token-input").value.trim();
  const msg   = document.getElementById("login-msg");

  if (!token) { showMsg(msg, "Please paste your access token.", "err"); return; }
  showMsg(msg, "Verifying…", "info");

  // Route through background — Chrome MV3 blocks popup fetch to external URLs
  const result = await sendMsg({ action: "verifyToken", token });

  if (!result?.ok) {
    showMsg(msg, "Invalid token. Check and try again.", "err");
    return;
  }

  const user = result.user;
  await setStorage({
    token,
    userName:   user.name,
    userPhone:  user.phone_number || "",
    userAvatar: user.avatar_url   || "",
    notifCount: 0,
  });

  showMsg(msg, `Connected as ${user.name}`, "ok");
  setTimeout(() => showMain(token, 0), 700);
}

// ── Main ─────────────────────────────────────────────────────────────────────

async function showMain(token, notifCount) {
  viewLogin.classList.remove("active");
  viewMain.classList.add("active");

  dot.className = "status-dot active";
  statusText.textContent = "LIVE";
  pollStatus.textContent = "POLLING EVERY 15S";

  const { userName, userPhone, userAvatar } = await getStorage(["userName", "userPhone", "userAvatar"]);
  document.getElementById("user-name").textContent  = userName  || "User";
  document.getElementById("user-phone").textContent = userPhone || "";
  document.getElementById("stat-notifs").textContent = notifCount;

  const avatarEl = document.getElementById("user-avatar");
  if (userAvatar) {
    const img = document.createElement("img");
    img.src = userAvatar;
    img.style.cssText = "width:100%;height:100%;object-fit:cover;border-radius:50%";
    avatarEl.textContent = "";
    avatarEl.appendChild(img);
  }

  // Load groups + topics count — routed through background
  const groupsResult = await sendMsg({ action: "loadGroups" });
  if (groupsResult?.ok && groupsResult.groups) {
    document.getElementById("stat-groups").textContent = groupsResult.groups.length;
    let topicCount = 0;
    for (const g of groupsResult.groups) topicCount += (g.children_count || 0);
    document.getElementById("stat-topics").textContent = topicCount;
  }

  renderHistory();
  renderPreview();

  // Poll button — disabled on open, enabled after 3s
  const pollBtn = document.getElementById("poll-now-btn");
  setTimeout(() => { pollBtn.disabled = false; }, 3000);

  pollBtn.addEventListener("click", async () => {
    pollBtn.disabled = true;
    pollBtn.innerHTML = '<span class="icon pulse">⚡</span> Polling…';
    dot.className = "status-dot polling";
    statusText.textContent = "POLLING";

    await sendMsg({ action: "poll" });
    await new Promise(r => setTimeout(r, 1500));

    const { notifCount: nc } = await getStorage(["notifCount"]);
    document.getElementById("stat-notifs").textContent = nc || 0;
    renderHistory();
    renderPreview();
    pollBtn.innerHTML = '<span class="icon">⚡</span> Poll now';
    dot.className = "status-dot active";
    statusText.textContent = "LIVE";
    setTimeout(() => { pollBtn.disabled = false; }, 15000);
  });

  // Clear history
  document.getElementById("clear-history-btn").addEventListener("click", async () => {
    await setStorage({ notifHistory: [] });
    renderHistory();
    renderPreview();
  });

  // Logout
  document.getElementById("logout-btn").addEventListener("click", () => {
    sendMsg({ action: "clearToken" }).then(() => {
      viewMain.classList.remove("active");
      document.getElementById("token-input").value = "";
      showLogin();
    });
  });
}

// ── Live Preview ─────────────────────────────────────────────────────────────

async function renderPreview() {
  const { notifHistory = [] } = await getStorage(["notifHistory"]);
  const container = document.getElementById("preview-content");
  container.innerHTML = "";

  if (notifHistory.length === 0) {
    const empty = document.createElement("div");
    empty.className = "preview-empty";
    empty.textContent = "No messages yet…";
    container.appendChild(empty);
    return;
  }

  const latest = notifHistory[0];

  const group = document.createElement("div");
  group.className = "preview-group";
  group.textContent = latest.groupName;

  const sender = document.createElement("div");
  sender.className = "preview-sender";
  sender.textContent = latest.sender;

  const text = document.createElement("div");
  text.className = "preview-text";
  text.textContent = latest.text;

  container.appendChild(group);
  container.appendChild(sender);
  container.appendChild(text);
}

// ── History ───────────────────────────────────────────────────────────────────

async function renderHistory() {
  const { notifHistory = [] } = await getStorage(["notifHistory"]);
  const list = document.getElementById("history-list");
  list.innerHTML = "";

  if (notifHistory.length === 0) {
    const empty = document.createElement("div");
    empty.className = "history-empty";
    empty.textContent = "Waiting for messages…";
    list.appendChild(empty);
    return;
  }

  for (const item of notifHistory) {
    const el = document.createElement("div");
    el.className = "history-item";

    const top = document.createElement("div");
    top.className = "hi-top";

    const senderEl = document.createElement("div");
    senderEl.className = "hi-sender";
    senderEl.textContent = item.sender;

    const timeEl = document.createElement("div");
    timeEl.className = "hi-time";
    timeEl.textContent = formatTime(item.ts);

    top.appendChild(senderEl);
    top.appendChild(timeEl);

    const groupEl = document.createElement("div");
    groupEl.className = "hi-group";
    groupEl.textContent = item.groupName;

    const textEl = document.createElement("div");
    textEl.className = "hi-text";
    textEl.textContent = item.text;

    el.appendChild(top);
    el.appendChild(groupEl);
    el.appendChild(textEl);
    list.appendChild(el);
  }
}

function formatTime(ts) {
  if (!ts) return "";
  const d = new Date(ts);
  return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

function showMsg(el, text, type) {
  el.textContent = text;
  el.className   = `msg show ${type}`;
}

init();
